<?php $__env->startSection('title'); ?>
    Listado de variantes
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="container" >
    <div class="card bg-dark text-center text-white">
        <div class="card-header">
            <h1 class="">Variantes</h1>
        </div>
        <div class="card-body">
            <table class="table table-responsive table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Modelo</th>
                        <th>Modelo(Específico)</th>
                        <th>Procesador</th>
                        <th>Rom</th>
                        <th>Ram</th>
                        <th>Camara principal</th>
                        <th>Selfie</th>
                        <th>MODIFICAR</th>
                        <th>CONSULTAR</th>
                        <th>BORRAR</th>
                    </tr>
                </thead>
                <tbody >
                        <?php $__empty_1 = true; $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $te): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <th>
                                    <?php echo e($te['id']); ?>

                                </th>
                                <td>
                                    <?php echo e($te->modelo['modelo']); ?>

                                </td>
                                <td>
                                    <?php echo e($te['numero_modelo']); ?>

                                </td>
                                <td>
                                    <?php echo e($te['procesador']); ?>

                                </td>
                                <td>
                                    <?php echo e($te['memoria_int']); ?>

                                </td>
                                <td>
                                    <?php echo e($te['memoria_ram']); ?>

                                </td>
                                <td>
                                    <?php echo e($te['cam_prin']); ?>

                                </td>
                                <td>
                                    <?php echo e($te['cam_frontal']); ?>

                                </td>
                                <td>
                                    <form action="<?php echo e(url('tel/'.$te->id.'/edit')); ?>" method="GET">
                                        <input type="text" name="idm" value="<?php echo e($te->modelo->marca['id']); ?>" hidden>
                                        <input type="text" name="idmo" value="<?php echo e($te->modelo['id']); ?>" hidden>
                                        <input type="text" name="seccion" value="0" hidden>
                                        <button class="btn btn-block btn-outline-primary" >
                                            <i class="fas fa-user-edit"></i>
                                        </button>
                                    </form>
                                </td>
                                <td>
                                    <a href="<?php echo e(url('tel/'.$te->id)); ?>">
                                        <button type="button" class="btn btn-block btn-outline-info"">
                                            <i class="fas fa-question"></i>
                                        </button>
                                    </a>
                                </td>
                                <td>
                                    <form action="<?php echo e(url('delvar', $te['id'])); ?>" method="GET">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="text" name="id" value="<?php echo e($te['id']); ?>" hidden>
                                        <input type="text" name="id_modelo" value="<?php echo e($te['id_modelo']); ?>" hidden>
                                        <button type="submit" class="btn btn-block btn-outline-danger"">
                                            <i class="fas fa-user-minus"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>no ai datos oiga</p>
                        <?php endif; ?>

                </tbody>
            </table>
        </div>
        <div class="card-footer">
            <h4>paginador ba aki XD</h4>
            
        </div>
    </div>
</div>
<br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prlv8\resources\views/modelos/variantes.blade.php ENDPATH**/ ?>