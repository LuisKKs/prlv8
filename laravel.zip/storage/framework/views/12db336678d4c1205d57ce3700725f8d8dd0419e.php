<?php $__env->startSection('title'); ?>
    Telefonos listado
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="container" >
    <div class="card bg-dark text-light">
        <div class="card-header">
            <h1 class="">Telefonos</h1>
        </div>
        <div class="card-body">
            <table class="table table-responsive highlight">
                <thead class="">
                    <tr>
                        <th scope="col">
                            ID
                        </th>
                        <th scope="col">
                            Modelo
                        </th>
                        <th scope="col">
                            Modelo(Específico)
                        </th>
                        <th scope="col">
                            Procesador
                        </th>
                        <th scope="col">
                            Rom
                        </th>
                        <th scope="col">
                            Ram
                        </th>
                        <th scope="col">
                            Camara principal
                        </th>
                        <th scope="col">
                            Selfie
                        </th>
                        <th scope="col">
                            MODIFICAR
                        </th>
                        <th scope="col">
                            CONSULTAR
                        </th>
                        <th scope="col">
                            BORRAR
                        </th>
                    </tr>
                </thead>
                <tbody class="grey-text text-lighten-3">
                    <?php $__empty_1 = true; $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th>
                                <?php echo e($registro['id']); ?>

                            </th>
                            <td>
                                <?php echo e($registro->modelo['modelo']); ?>

                            </td>
                            <td>
                                <?php echo e($registro['numero_modelo']); ?>

                            </td>
                            <td>
                                <?php echo e($registro['procesador']); ?>

                            </td>
                            <td>
                                <?php echo e($registro['memoria_int']); ?>

                            </td>
                            <td>
                                <?php echo e($registro['memoria_ram']); ?>

                            </td>
                            <td>
                                <?php echo e($registro['cam_prin']); ?>

                            </td>
                            <td>
                                <?php echo e($registro['cam_frontal']); ?>

                            </td>
                            <td>
                                <a href="<?php echo e(url('tel/'.$registro->id.'/edit')); ?>">
                                    <button class="btn btn-block btn-outline-primary" >
                                        <i class="fas fa-user-edit"></i>
                                    </button>
                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(url('tel/'.$registro->id)); ?>">
                                    <button type="button" class="btn btn-block btn-outline-info"">
                                        <i class="fas fa-question"></i>
                                    </button>
                                </a>
                            </td>
                            <td>
                                <form action="<?php echo e(url('tel', $registro['id'])); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <button type="submit" class="btn btn-block btn-outline-danger"">
                                        <i class="fas fa-user-minus"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>no ai datos oiga</p>
                    <?php endif; ?>
                </tbody>
            </table>
            <h5 class="lime-text text-darken-3">Crear nuevo registro</h5>

            <a href="<?php echo e(url('tel/create')); ?>">
                <button class="btn btn-block btn-outline-success">
                    <i class="fas fa-check"></i>
                </button>
            </a>
        </div>
        <div class="card-footer">
            <h4>paginador ba aki XD</h4>
            
        </div>
    </div>
</div>
<br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prlv8\resources\views/modelos/index.blade.php ENDPATH**/ ?>