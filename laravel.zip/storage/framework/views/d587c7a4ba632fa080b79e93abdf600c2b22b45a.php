<?php $__env->startSection('title'); ?>
    Edicion de modelo
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br><br>
<div class="container">
    <div class="card bg-dark text-light text-center">
        <div class="card-header">
            <h4>Editar Modelo</h4>
        </div>
        <form method="POST" action="<?php echo e(url('mod/'.$row->id)); ?>">
            <?php echo e(csrf_field()); ?>

            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="_method" value="PATCH">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input type="text" hidden name="id" value="<?php echo e($row->id); ?>">
            <div class=" card-body">
                <label for="marca">Marca:</label>
                <select name="id_marca" id="marca" class="form-control form-inline bg-dark text-light text-center">
                    <?php $__currentLoopData = $mar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($mar['id']); ?>"><?php echo e($mar['marca']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <!--input type="text" id="marca" name="id_marca" value="" class=" form-control form-inline bg-dark text-light text-center" required-->
                <label for="modelo">Modelo:</label>
                <input type="text" id="modelo" name="modelo" value="<?php echo e($row->modelo); ?>" class=" form-control form-inline bg-dark text-light text-center" required>
            </div>
                    <?php echo e(csrf_field()); ?>

            <div class=" card-footer">
                <button class="btn btn-block btn-success" style="width: 100%" type="submit" title="registrar">
                    <i class="fas fa-check"></i>
                </button>
                <a href="<?php echo e(url('mar/'.$row['id'])); ?>" class="btn btn-block btn-danger"><i class="fas fa-check"></i></a>
            </div>
        </form>
    </div>
</div>
<br><br>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prlv8\resources\views/modelos/edit.blade.php ENDPATH**/ ?>