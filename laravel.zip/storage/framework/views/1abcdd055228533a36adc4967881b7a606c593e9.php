<?php $__env->startSection('title'); ?>
    Modelos de marca
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<br><br>
<div class="container">
    <div class="card bg-dark text-white text-center" >
        <div class="card-header">
            <h5><h4 class="">Modelos de marca</h4></h5>
        </div>
        <div class="card-body">
            <table class="table table-responsive table-hover">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Editar</th>
                        <th>Registrar variante</th>
                        <th>Eliminar Modelo</th>
                        <th>Variantes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $mod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($row['id']); ?></td>
                            <td><?php echo e($row['marca']); ?></td>
                            <td><?php echo e($mod['modelo']); ?></td>
                            <td>
                                <a href="<?php echo e(url('mod/'.$mod->id.'/edit')); ?>">
                                    <button class="btn btn-block btn-outline-primary" >
                                        <i class="fas fa-user-edit"></i>
                                    </button>
                                </a>
                            </td>
                            <td>
                                <form action="<?php echo e(url('tel/create')); ?>" method="GET">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <input type="text" name="id" value="<?php echo e($mod['id']); ?>" hidden>
                                    <input type="text" name="id_marca" value="<?php echo e($row['id']); ?>" hidden>
                                    <button type="submit" class="btn btn-block btn-outline-info"">
                                        <i class="far fa-plus-square"></i>
                                    </button>
                                </form>
                            </td>
                            <td>
                                <form action="<?php echo e(url('mod', $mod['id'])); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <input type="text" name="id" value="<?php echo e($mod['id']); ?>" hidden>
                                    <input type="text" name="id_marca" value="<?php echo e($row['id']); ?>" hidden>
                                    <button type="submit" class="btn btn-block btn-outline-danger"">
                                        <i class="fas fa-user-minus"></i>
                                    </button>
                                </form>
                            </td>
                            <td>
                                <form action="<?php echo e(url('vervar')); ?>" method="GET">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <input type="text" name="id" value="<?php echo e($mod['id']); ?>" hidden>
                                    <input type="text" name="id_marca" value="<?php echo e($row['id']); ?>" hidden>
                                    <button type="submit" class="btn btn-block btn-outline-info"">
                                        <i class="far fa-plus-square"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
            <div>
                <h5>Registrar Modelo</h5>
                <a href="<?php echo e(url('regmod/'.$row['id'])); ?>" class="btn btn-success btn-block"><i class="fas fa-check"></i></a>
            </div>
            <div>
                <h5>Regresar a listado de marcas</h5>
                <a href="<?php echo e(url('mar')); ?>" class="btn btn-warning btn-block"><i class="fas fa-check"></i></a>
            </div>
        </div>
    </div>
</div>
<br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prlv8\resources\views/marcas/info.blade.php ENDPATH**/ ?>