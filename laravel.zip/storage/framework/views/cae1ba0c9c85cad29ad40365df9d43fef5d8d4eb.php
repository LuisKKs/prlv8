<?php $__env->startSection('title'); ?>
    Editar refaccion
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<br><br>
<div class="container">
    <div class="card bg-dark text-light text-center">
        <div class="card-header">
            <h4>Editar refaccion</h4>
        </div>
        <form method="POST" action="<?php echo e(url('ref/'.$row->id)); ?>">
            <?php echo e(csrf_field()); ?>

            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="_method" value="PATCH">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input type="text" hidden name="id" value="<?php echo e($row->id); ?>">
            <div class=" card-body">
                <label for="nota">Nota:</label>
                <input type="text" id="nota" name="nota" value="<?php echo e($row->nota); ?>" class=" form-control form-inline bg-dark text-light text-center" required>
                <label for="marca">Marca:</label>
                <input type="text" id="marca" name="marca_ref" value="<?php echo e($row->marca_ref); ?>" class=" form-control form-inline bg-dark text-light text-center" required>
                <label for="modelo">Modelo:</label>
                <input type="text" id="modelo" name="modelo_ref" value="<?php echo e($row->modelo_ref); ?>" class=" form-control form-inline bg-dark text-light text-center" required>
                <label for="tipo">Refaccion:</label>
                <select name="id_ref" id="tipo" class=" bg-dark text-light text-center" required>
                    <option value="" disabled >Seleccione el tipo de refaccion</option>
                    <?php $__currentLoopData = $ref; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($r['id']); ?>"><?php echo e($r['tipo']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label for="tel">Telefono:</label>
                <select name="id_tel" id="tel" class=" bg-dark text-light text-center" required>
                    <option value="" disabled >Seleccione el modelo especifico</option>
                    <?php $__currentLoopData = $tel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($t['id']); ?>"><?php echo e($t['numero_modelo']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
                    <?php echo e(csrf_field()); ?>

            <div class=" card-footer">
                <button class="btn btn-block btn-success" style="width: 100%" type="submit" title="registrar">
                    <i class="fas fa-check"></i>
                </button>
                <a href="<?php echo e(url('ref')); ?>" class="btn btn-block btn-danger"><i class="fas fa-check"></i></a>
            </div>
        </form>
    </div>
</div>
<br><br>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prlv8\resources\views/refacciones/edit.blade.php ENDPATH**/ ?>