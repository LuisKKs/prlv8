<?php $__env->startSection('title'); ?>
    Editar accesorio
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<br><br>
<div class="container">
    <div class="card bg-dark text-light text-center">
        <div class="card-header">
            <h4>Registrar accesorio</h4>
        </div>
        <form method="POST" action="<?php echo e(url('acc/'.$acm->id)); ?>">
            <?php echo e(csrf_field()); ?>

            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="_method" value="PATCH">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input type="text" hidden name="id" value="<?php echo e($acm->id); ?>">
            <div class=" card-body">
                <label for="tipo">Accsesorio:</label>
                <select name="id_accesorio" id="tipo" class=" bg-dark text-light text-center" required>
                    <option value="" disabled >Seleccione el tipo de accesorio</option>
                    <?php $__currentLoopData = $acc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($acc['id']); ?>"><?php echo e($acc['tipo']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label for="modelo">Modelo:</label>
                <select name="id_modelo" id="modelo" class=" bg-dark text-light text-center" required>
                    <option value="" disabled >Seleccione el modelo</option>
                    <?php $__currentLoopData = $mod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($mod['id']); ?>"><?php echo e($mod['modelo']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br>
                <label for="nota">Nota:</label>
                <input type="text" id="nota" name="nota" value="<?php echo e($acm['nota']); ?>" class=" form-control form-inline bg-dark text-light text-center" required>
                <label for="marca">Marca:</label>
                <input type="text" id="marca" name="marca_acc" value="<?php echo e($acm['marca_acc']); ?>" class=" form-control form-inline bg-dark text-light text-center" required>
                <label for="modelo">Modelo:</label>
                <input type="text" id="modelo" name="modelo_acc" value="<?php echo e($acm['modelo_acc']); ?>" class=" form-control form-inline bg-dark text-light text-center" required>
            </div>
                    <?php echo e(csrf_field()); ?>

            <div class=" card-footer">
                <button class="btn btn-block btn-success" style="width: 100%" type="submit" title="registrar">
                    <i class="fas fa-check"></i>
                </button>
                <a href="<?php echo e(url('acc')); ?>" class="btn btn-block btn-danger"><i class="fas fa-check"></i></a>
            </div>
        </form>
    </div>
</div>
<br><br>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prlv8\resources\views/accesorios/edit.blade.php ENDPATH**/ ?>