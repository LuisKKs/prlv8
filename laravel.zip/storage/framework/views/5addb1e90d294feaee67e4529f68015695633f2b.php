<nav class="navbar navbar-expand-lg navbar-dark bg-dark text-center">
    <a class="navbar-brand " href="<?php echo e(url('/')); ?>">Telefonos</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse text-center" id="navbarTogglerDemo02">
        <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(url('mar')); ?>">Marcas</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('tel')); ?>">Telefonos</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('acc')); ?>">Accesorios</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('ref')); ?>">Refacciones</a>
            </li>
        </ul>
        <ul class="navbar-nav mr-auto my-2 my-lg-0">
            <li>
                <a id="" class="nav-link " href="#">
                    <?php echo e(Auth::user()->name); ?>

                </a>
            </li>
            <li>
                <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>
            </li>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none" hidden>
                <?php echo csrf_field(); ?>
            </form>
        </ul>
    </div>
</nav>
<div class=" alert">
    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH C:\laragon\www\prlv8\resources\views/layouts/header.blade.php ENDPATH**/ ?>