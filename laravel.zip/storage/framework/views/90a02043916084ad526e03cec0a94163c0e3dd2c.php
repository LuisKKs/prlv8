<?php $__env->startSection('title'); ?>
    Marcas editar
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<br><br>
<div class="container">
    <div class="card bg-dark text-light text-center">
        <div class="card-header">
            <h4>Editar marca</h4>
        </div>
        <form method="POST" action="<?php echo e(url('mar/'.$row->id)); ?>">
            <?php echo e(csrf_field()); ?>

            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="_method" value="PATCH">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input type="text" hidden name="id" value="<?php echo e($row->id); ?>">
            <div class=" card-body">
                <label for="marca">Marca:</label>
                <input type="text" id="marca" name="marca" value="<?php echo e($row->marca); ?>" class=" form-control form-inline bg-dark text-light text-center">
            </div>
                    <?php echo e(csrf_field()); ?>

            <div class=" card-footer">
                <button class="btn lime darken-4" style="width: 100%" type="submit" title="registrar">
                    <i class="fas fa-check"></i>
                </button>
                <a href="<?php echo e(url('mar')); ?>" class="btn btn-block btn-danger"><i class="fas fa-check"></i></a>
            </div>
        </form>
    </div>
</div>
<br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prlv8\resources\views/marcas/edit.blade.php ENDPATH**/ ?>