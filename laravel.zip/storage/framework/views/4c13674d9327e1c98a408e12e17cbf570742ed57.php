<?php $__env->startSection('title','Listado de marcas'); ?>
<?php $__env->startSection('content'); ?>
<br />
<br />
<br />
<p> Listado de Marcas</p>
			<table class="table trable-striped table-bordered">
			    <thead>
				    <tr>
                        <td> ID</td>
                        <td> Marca </td>
                        <!--td> Estado </td-->
				    </tr>
			    </thead>
			    <tbody>
				    <?php $__empty_1 = true; $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				    <tr>
						<td> <?php echo e($marca->id); ?> </td>
						<td> <?php echo e($marca->marca); ?> </td>
						<!--td>  </td-->
					</tr>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan=2> No se encontraron registros</td>
                    <tr>
			        <?php endif; ?>
			    </tbody>
		    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pdf.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prlv8\resources\views/pdf/listadomarca.blade.php ENDPATH**/ ?>