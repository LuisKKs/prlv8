<?php $__env->startSection('title'); ?>
    Listado de telefonos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="container text-center" >
    <div class="card bg-dark text-light">
        <div class="card-header">
            <h1 class="">Telefonos</h1>
        </div>
        <div>
            <a href="<?php echo e(url('prnttel')); ?>" class="btn btn-block btn-outline-info">Imprimir listado de telefonos <i class="fas fa-print"></i></a>
        </div>
        <div class="card-body">
            <table class="table responsive-table">
                <thead class="">
                    <tr>
                        <th scope="col">
                            ID
                        </th>
                        <th scope="col">
                            Marca
                        </th>
                        <th scope="col">
                            Modelo
                        </th>
                        <th scope="col">
                            Modelo(Específico)
                        </th>
                        <th scope="col">
                            MODIFICAR
                        </th>
                        <th scope="col">
                            CONSULTAR
                        </th>
                        <th scope="col">
                            BORRAR
                        </th>
                    </tr>
                </thead>
                <tbody class="grey-text text-lighten-3">
                    <?php $__empty_1 = true; $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th>
                                <?php echo e($registro['id']); ?>

                            </th>
                            <td>
                                <?php echo e($registro->modelo->marca['marca']); ?>

                            </td>
                            <td>
                                <?php echo e($registro->modelo['modelo']); ?>

                            </td>
                            <td>
                                <?php echo e($registro['numero_modelo']); ?>

                            </td>
                            <td>
                                <form action="<?php echo e(url('tel/'.$registro->id.'/edit')); ?>" method="GET">
                                    <input type="text" name="idm" value="<?php echo e($registro->modelo->marca['id']); ?>" hidden>
                                    <input type="text" name="idmo" value="<?php echo e($registro->modelo['id']); ?>" hidden>
                                    <input type="text" name="seccion" value="1" hidden>
                                    <button class="btn btn-block btn-outline-primary" >
                                        <i class="fas fa-user-edit"></i>
                                    </button>
                                </form>
                            </td>
                            <td>
                                <a href="<?php echo e(url('tel/'.$registro->id)); ?>">
                                    <button type="button" class="btn btn-block btn-outline-info"">
                                        <i class="fas fa-question"></i>
                                    </button>
                                </a>
                            </td>
                            <td>
                                <form action="<?php echo e(url('tel', $registro['id'])); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <button type="submit" class="btn btn-block btn-outline-danger"">
                                        <i class="fas fa-user-minus"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>no ai datos oiga</p>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer" style="height: 50px">
            <?php echo e($row->links()); ?>

        </div>
    </div>
</div>
<br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\prlv8\resources\views/telefonos/index.blade.php ENDPATH**/ ?>