<?php

namespace App\Http\Controllers;

use App\Models\ref;
use Illuminate\Http\Request;

class refCont extends Controller
{
    public function index()
    {
        //
    }
    public function create()
    {
        //
    }
    public function store(Request $request)
    {
        //
    }
    public function show(ref $ref)
    {
        //
    }
    public function edit(ref $ref)
    {
        //
    }
    public function update(Request $request, ref $ref)
    {
        //
    }
    public function destroy(ref $ref)
    {
        //
    }
}
