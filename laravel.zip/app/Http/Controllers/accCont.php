<?php

namespace App\Http\Controllers;

use App\Models\acc;
use Illuminate\Http\Request;

class accCont extends Controller
{
    public function index()
    {
        //
    }
    public function create()
    {
        //
    }
    public function store(Request $request)
    {
        //
    }
    public function show(acc $acc)
    {
        //
    }
    public function edit(acc $acc)
    {
        //
    }
    public function update(Request $request, acc $acc)
    {
        //
    }
    public function destroy(acc $acc)
    {
        //
    }
}
